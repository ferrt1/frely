const metrics = [
  {
    stat: "20 hrs",
    label: "ahorradas por semana",
    company: "Salon Sofia",
  },
  {
    stat: "98%",
    label: "de respuestas instantaneas",
    company: "Restaurante Don Pedro",
  },
  {
    stat: "300%",
    label: "mas reservas online",
    company: "Clinica Dental Sur",
  },
  {
    stat: "24/7",
    label: "atencion automatica",
    company: "Gym Fitness Plus",
  },
]

export function Metrics() {
  return (
    <section className="bg-foreground py-16 sm:py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-background/10 rounded-2xl overflow-hidden">
          {metrics.map((metric, index) => (
            <div
              key={index}
              className="bg-foreground p-6 sm:p-8 flex flex-col"
            >
              <p className="text-2xl sm:text-3xl font-semibold text-background">
                {metric.stat}
              </p>
              <p className="text-background/70 text-sm mt-1">
                {metric.label}
              </p>
              <p className="text-background/40 text-xs mt-4 font-medium uppercase tracking-wider">
                {metric.company}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
